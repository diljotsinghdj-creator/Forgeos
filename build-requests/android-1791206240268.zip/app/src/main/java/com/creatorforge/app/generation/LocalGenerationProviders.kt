package com.creatorforge.app.generation

import android.content.Context
import com.creatorforge.app.model.AspectRatio
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

interface ImageGenerationProvider { suspend fun generate(prompt:String, ratio:AspectRatio):GenerationResult }
interface LocalVoiceEngine { suspend fun generate(text:String):GenerationResult }

data class LocalProviderConfig(val baseUrl:String){ fun normalized()=baseUrl.trim().trimEnd('/') }

class SelfHostedImageProvider(private val context:Context, private val config:LocalProviderConfig):ImageGenerationProvider {
 private val client=OkHttpClient.Builder().connectTimeout(10,TimeUnit.SECONDS).readTimeout(120,TimeUnit.SECONDS).build()
 override suspend fun generate(prompt:String,ratio:AspectRatio):GenerationResult=withContext(Dispatchers.IO){
  try{
   val base=config.normalized(); if(base.isBlank()) return@withContext GenerationResult.Failure("Local provider URL not configured")
   val aspect=when(ratio){AspectRatio.VERTICAL_9_16->"9:16";AspectRatio.LANDSCAPE_16_9->"16:9";AspectRatio.SQUARE_1_1->"1:1"}
   val body=JSONObject().put("prompt",prompt).put("aspect_ratio",aspect).toString().toRequestBody("application/json".toMediaType())
   val r=client.newCall(Request.Builder().url("$base/v1/images/generate").post(body).build()).execute()
   if(!r.isSuccessful)return@withContext GenerationResult.Failure("Local image provider HTTP ${r.code}")
   val bytes=r.body?.bytes()?:return@withContext GenerationResult.Failure("Empty local image response")
   val png=bytes.size>8&&bytes.copyOfRange(0,8).contentEquals(byteArrayOf(0x89.toByte(),0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A)); val jpg=bytes.size>3&&bytes[0]==0xFF.toByte()&&bytes[1]==0xD8.toByte()&&bytes[2]==0xFF.toByte()
   if(bytes.size<10_000||(!png&&!jpg))return@withContext GenerationResult.Failure("Local provider returned an unverified image")
   val dir=File(context.filesDir,"generated_images").apply{mkdirs()};val f=File(dir,"local_${System.currentTimeMillis()}.${if(png)"png" else "jpg"}");f.writeBytes(bytes);GenerationResult.Success(f)
  }catch(e:Exception){GenerationResult.Failure("Local provider unavailable: ${e.message?:"connection error"}")}
 }
}

class SelfHostedVoiceEngine(private val context:Context,private val config:LocalProviderConfig):LocalVoiceEngine{
 private val client=OkHttpClient.Builder().connectTimeout(10,TimeUnit.SECONDS).readTimeout(120,TimeUnit.SECONDS).build()
 override suspend fun generate(text:String):GenerationResult=withContext(Dispatchers.IO){
  try{val base=config.normalized();if(base.isBlank())return@withContext GenerationResult.Failure("Local provider URL not configured")
   val body=JSONObject().put("text",text).put("format","wav").toString().toRequestBody("application/json".toMediaType());val r=client.newCall(Request.Builder().url("$base/v1/voice/generate").post(body).build()).execute();if(!r.isSuccessful)return@withContext GenerationResult.Failure("Local voice provider HTTP ${r.code}");val bytes=r.body?.bytes()?:return@withContext GenerationResult.Failure("Empty voice response");if(bytes.size<44||String(bytes.copyOfRange(0,4))!="RIFF")return@withContext GenerationResult.Failure("Unverified WAV response");val dir=File(context.filesDir,"generated_audio").apply{mkdirs()};val f=File(dir,"local_${System.currentTimeMillis()}.wav");f.writeBytes(bytes);GenerationResult.Success(f)
  }catch(e:Exception){GenerationResult.Failure("Local voice unavailable: ${e.message?:"connection error"}")}}
}
