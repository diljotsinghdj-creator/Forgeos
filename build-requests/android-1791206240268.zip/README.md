# CreatorForge v1.0 RC6

RC6 preserves the RC4/RC5 working project pipeline and makes the Studio workflow an explicit fifth navigation destination.

## RC6 device-test gates
- Home must display `RC6 • STUDIO + LOCAL-FIRST`.
- Bottom navigation must display Home / Create / Projects / Studio / Settings.
- Studio must open and show timeline/caption/render-readiness data for a saved project.
- Settings must state Local / self-hosted as PRIMARY PROVIDER and Replicate as optional fallback.
- Existing Create and Projects flows must remain intact.

A successful Gradle compile alone is not release acceptance. Device UI verification is required.

## RC7
Local/self-hosted provider contract is now executable. Scene generation no longer requires Replicate: Settings stores a worker base URL; image requests use POST /v1/images/generate and accept only verified PNG/JPEG; voice foundation uses POST /v1/voice/generate and accepts only verified RIFF/WAV. Scene state is persisted through GENERATING/READY/FAILED and Studio displays real state. Paid providers remain outside the primary path.
