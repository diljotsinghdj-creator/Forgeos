# CreatorForge v1.0 RC6

RC6 preserves the RC4/RC5 working project pipeline and makes the Studio workflow an explicit fifth navigation destination.

## RC6 device-test gates
- Home must display `RC6 • STUDIO + LOCAL-FIRST`.
- Bottom navigation must display Home / Create / Projects / Studio / Settings.
- Studio must open and show timeline/caption/render-readiness data for a saved project.
- Settings must state Local / self-hosted as PRIMARY PROVIDER and Replicate as optional fallback.
- Existing Create and Projects flows must remain intact.

A successful Gradle compile alone is not release acceptance. Device UI verification is required.
