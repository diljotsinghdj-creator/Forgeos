from pathlib import Path
r=Path(__file__).parents[1]
files={p.name:p.read_text(errors='ignore') for p in r.rglob('*.kt')}
alltext='\n'.join(files.values())
checks={
'v1 package': 'applicationId = "com.forgeos.app"' in (r/'app/build.gradle.kts').read_text(),
'crash recovery':'recoverInterrupted' in alltext and 'INTERRUPTED' in alltext,
'controlled build':'ProcessBuilder' in alltext and '--no-daemon' in alltext,
'fail closed toolchain':'No Gradle wrapper or managed Gradle toolchain installed.' in alltext,
'apk validation':'apk.length()>1024' in alltext,
'cancel':'destroyForcibly' in alltext,
'install intent':'application/vnd.android.package-archive' in alltext,
'no fake success':'fake success' not in alltext.lower(),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+': '+k)
assert all(checks.values())
