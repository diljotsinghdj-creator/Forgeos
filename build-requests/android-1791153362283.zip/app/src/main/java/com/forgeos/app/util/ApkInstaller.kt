package com.forgeos.app.util
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
object ApkInstaller { fun install(context:Context,apk:File){ require(apk.isFile && apk.length()>1024); val uri=FileProvider.getUriForFile(context,"${context.packageName}.files",apk); context.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)) } }
