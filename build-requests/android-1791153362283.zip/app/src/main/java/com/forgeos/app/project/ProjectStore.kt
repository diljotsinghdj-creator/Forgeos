package com.forgeos.app.project

import android.content.Context
import com.forgeos.app.model.ForgeProject
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class ProjectStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("forgeos_projects", Context.MODE_PRIVATE)
    fun all(): List<ForgeProject> = runCatching {
        val a=JSONArray(prefs.getString("projects","[]")); (0 until a.length()).map { i -> a.getJSONObject(i).let { ForgeProject(it.getString("id"),it.getString("name"),it.getString("rootPath"),it.getLong("importedAt")) } }
    }.getOrDefault(emptyList())
    fun add(name:String, root:File): ForgeProject { val p=ForgeProject(UUID.randomUUID().toString(),name,root.absolutePath); save(all()+p); return p }
    fun remove(id:String){ save(all().filterNot{it.id==id}) }
    private fun save(items:List<ForgeProject>){ val a=JSONArray(); items.forEach { a.put(JSONObject().put("id",it.id).put("name",it.name).put("rootPath",it.rootPath).put("importedAt",it.importedAt)) }; prefs.edit().putString("projects",a.toString()).apply() }
}
