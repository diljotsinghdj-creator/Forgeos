package com.forgeos.app.model

enum class JobState { QUEUED, RUNNING, SUCCEEDED, FAILED, CANCELLED, INTERRUPTED }
data class ForgeProject(val id:String,val name:String,val rootPath:String,val importedAt:Long=System.currentTimeMillis())
data class BuildJob(val id:String,val projectId:String,val task:String,val state:JobState,val createdAt:Long,val updatedAt:Long,val exitCode:Int?=null,val logPath:String?=null,val apkPath:String?=null,val error:String?=null)
data class ToolchainStatus(val java:Boolean,val gradle:Boolean,val androidSdk:Boolean,val adb:Boolean,val detail:String)
