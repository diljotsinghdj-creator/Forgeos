package com.forgeos.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.forgeos.app.build.*
import com.forgeos.app.model.*
import com.forgeos.app.project.ProjectStore
import java.io.File
import kotlin.concurrent.thread

private val Gold=Color(0xFFD4AF37); private val Black=Color(0xFF090909); private val Panel=Color(0xFF151515)
class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); val journal=BuildJournal(this); journal.recoverInterrupted(); setContent{ MaterialTheme(colorScheme=darkColorScheme(primary=Gold,background=Black,surface=Panel)){ ForgeApp(ProjectStore(this),journal,BuildEngine(this,journal),filesDir) } }}
}
@Composable fun ForgeApp(store:ProjectStore,journal:BuildJournal,engine:BuildEngine,home:File){
 var projects by remember{mutableStateOf(store.all())}; var jobs by remember{mutableStateOf(journal.load())}; var selected by remember{mutableStateOf<ForgeProject?>(projects.firstOrNull())}; var status by remember{mutableStateOf(ToolchainDetector.detect(home))}
 Surface(Modifier.fillMaxSize(),color=Black){ Column(Modifier.fillMaxSize().padding(18.dp)){ Text("FORGEOS",style=MaterialTheme.typography.headlineLarge,color=Gold); Text("Android build workstation • v1.0",color=Color.Gray); Spacer(Modifier.height(18.dp)); Card(colors=CardDefaults.cardColors(containerColor=Panel)){Column(Modifier.padding(16.dp)){Text("TOOLCHAIN",color=Gold);Text(status.detail); if(!status.gradle||!status.androidSdk) Text("Toolchain incomplete — builds fail closed until a valid JDK/Gradle/Android SDK is provisioned.",color=Color(0xFFFFB4AB)) }}; Spacer(Modifier.height(12.dp)); Row{Button(onClick={status=ToolchainDetector.detect(home)}){Text("RECHECK")};Spacer(Modifier.width(8.dp));Button(enabled=selected!=null,onClick={val p=selected?:return@Button; thread{engine.build(p){j->jobs=(jobs.filterNot{it.id==j.id}+j)}}}){Text("BUILD APK")};Spacer(Modifier.width(8.dp));OutlinedButton(onClick={engine.cancel()}){Text("CANCEL")}}; Spacer(Modifier.height(16.dp)); Text("PROJECTS",color=Gold); if(projects.isEmpty()) Text("No project imported yet. v1.0 core is ready for Storage Access Framework import wiring.",color=Color.Gray) else LazyColumn(Modifier.weight(1f)){items(projects){p->Card(Modifier.fillMaxWidth().padding(vertical=5.dp),colors=CardDefaults.cardColors(containerColor=Panel),onClick={selected=p}){Column(Modifier.padding(14.dp)){Text(p.name,color=if(selected?.id==p.id) Gold else Color.White);Text(p.rootPath,color=Color.Gray)}}}}; Text("BUILD HISTORY",color=Gold); jobs.takeLast(3).reversed().forEach{j->Text("${j.task}: ${j.state}${j.exitCode?.let{" ($it)"}?:""}",color=if(j.state==JobState.SUCCEEDED) Color(0xFF7EE787) else Color.LightGray)} }}
}
