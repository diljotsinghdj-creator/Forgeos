# CreatorForge v1.0 RC2

RC2 closes the source-level narration pipeline blocker from RC1.

## Added
- Android MediaExtractor/MediaCodec decoding for narration assets (including MP3 when the device decoder supports it).
- PCM downmix to mono and linear sample-rate conversion.
- Timeline-accurate trim/pad per scene.
- AAC-LC encoding at 44.1 kHz / 128 kbps.
- M4A/MP4 audio-only output with MediaMuxer.
- Audio-track verification before final A/V mux.
- Cancellation and fail-closed cleanup.

## Acceptance status
Source architecture is now wired for real visual + narration + captions -> H.264/AAC MP4.
This package is still an RC because an Android SDK/device build and end-to-end device render have not been executed in this environment. It must not be called v1.0 Final until that runtime acceptance test passes.


## RC5
- Exposes the existing timeline/caption engine through a new Studio tab.
- Adds project render-readiness and caption/timeline inspection.
- Keeps RC4 project creation and verified-image behavior intact.
- Replicate remains optional legacy provider while local/self-hosted provider work proceeds.
