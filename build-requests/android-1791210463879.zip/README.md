# CreatorForge v1.0 RC8

RC8 preserves the verified RC7.1 UI/project/Studio flow and hardens the local-first worker boundary.

Changes:
- worker `/health` connection test in Settings
- URL validation before generation
- bounded connect/read/call timeouts
- fail-closed PNG/JPEG and WAV signature verification retained
- HTTP error details bounded for diagnostics
- SHA-256-derived asset filenames for traceability/dedup visibility
- RC7.1 project storage compatibility preserved

RC8 does not claim real model inference until a self-hosted worker is connected and device-tested.
