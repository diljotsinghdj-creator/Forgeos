package com.creatorforge.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.creatorforge.app.data.ProjectStore
import com.creatorforge.app.generation.GenerationResult
import com.creatorforge.app.generation.ReplicateImageProvider
import com.creatorforge.app.model.*
import com.creatorforge.app.security.SecureTokenStore
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

private val Gold=Color(0xFFD4AF37); private val Black=Color(0xFF090909); private val Panel=Color(0xFF151515)
class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{CreatorForge()}}}

@Composable fun CreatorForge(){
 val context=androidx.compose.ui.platform.LocalContext.current; val store=remember{ProjectStore(context)}; val secure=remember{SecureTokenStore(context)}
 var projects by remember{mutableStateOf(store.load())}; var tab by remember{mutableIntStateOf(0)}
 fun persist(next:List<CreatorProject>){projects=next;store.save(next)}
 MaterialTheme(colorScheme=darkColorScheme(primary=Gold,background=Black,surface=Panel)){Scaffold(bottomBar={NavigationBar(containerColor=Panel){listOf("Home","Create","Projects","Settings").forEachIndexed{i,n->NavigationBarItem(selected=tab==i,onClick={tab=i},label={Text(n)},icon={Text(if(tab==i)"◆" else "◇",color=Gold)})}}}){pad->Box(Modifier.fillMaxSize().padding(pad).padding(18.dp)){when(tab){0->Home(projects.size);1->Create{p->persist(projects+p);tab=2};2->Projects(projects,secure,::persist);else->Settings(secure)}}}}
}
@Composable fun Header(t:String,s:String){Column{Text(t,color=Gold,fontSize=30.sp);Text(s,color=Color.LightGray);Spacer(Modifier.height(18.dp))}}
@Composable fun Home(count:Int){Column{Header("CREATORFORGE","AI filmmaking workspace");Card{Column(Modifier.padding(18.dp)){Text("v0.7 TIMELINE + CAPTIONS",color=Gold);Text("$count saved projects");Text("Timeline • captions • synchronized scene timing • persistent recovery queue")}}}}
@Composable fun Create(done:(CreatorProject)->Unit){var prompt by remember{mutableStateOf("")};var long by remember{mutableStateOf(false)};Column{Header("CREATE","Start with an idea");OutlinedTextField(prompt,{prompt=it},Modifier.fillMaxWidth(),label={Text("Describe your video")},minLines=5);Row{Switch(long,{long=it});Text(if(long)" Long-form" else " Short-form",Modifier.padding(top=12.dp))};Button(enabled=prompt.isNotBlank(),onClick={val c=if(long)10 else 5;done(CreatorProject(UUID.randomUUID().toString(),prompt.take(40),if(long)ProjectType.LONG_FORM else ProjectType.SHORT_FORM,if(long)AspectRatio.LANDSCAPE_16_9 else AspectRatio.VERTICAL_9_16,prompt,(1..c).map{i->Scene(UUID.randomUUID().toString(),i,"Scene $i","Narration planned for scene $i.","Hyper-realistic cinematic scene $i. $prompt",if(long)12 else 6)}))}){Text("CREATE PROJECT")}}}

@Composable fun Projects(projects:List<CreatorProject>,secure:SecureTokenStore,persist:(List<CreatorProject>)->Unit){
 val context=androidx.compose.ui.platform.LocalContext.current; val provider=remember{ReplicateImageProvider(context)}; val scope=rememberCoroutineScope(); var busy by remember{mutableStateOf<String?>(null)}; var message by remember{mutableStateOf<String?>(null)}
 Column{Header("PROJECTS","Generate verified scene visuals");message?.let{Text(it,color=if(it.startsWith("PASS"))Gold else MaterialTheme.colorScheme.error);Spacer(Modifier.height(8.dp))};if(projects.isEmpty())Text("No projects yet.") else LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp)){items(projects,key={it.id}){p->Card{Column(Modifier.padding(16.dp)){Text(p.title,color=Gold,fontSize=20.sp);Text("${p.scenes.size} scenes");Spacer(Modifier.height(8.dp));p.scenes.sortedBy{it.order}.forEach{s->HorizontalDivider();Spacer(Modifier.height(8.dp));Text("${s.order}. ${s.title}",color=Gold);Text(s.visualPrompt,color=Color.LightGray);s.visualAssetPath?.let{path->Spacer(Modifier.height(8.dp));AsyncImage(model=File(path),contentDescription="Generated scene ${s.order}",modifier=Modifier.fillMaxWidth().height(180.dp))};Button(enabled=busy==null&&secure.hasToken(),onClick={val token=secure.load();if(token.isNullOrBlank()){message="Provider token required";return@Button};busy=s.id;message="Generating scene ${s.order}…";scope.launch{when(val r=provider.generate(token,s.visualPrompt,p.aspectRatio)){is GenerationResult.Success->{val updated=projects.map{proj->if(proj.id!=p.id)proj else proj.copy(scenes=proj.scenes.map{scene->if(scene.id==s.id)scene.copy(status=SceneStatus.READY,visualAssetPath=r.file.absolutePath) else scene})};persist(updated);message="PASS: verified image saved for scene ${s.order}"};is GenerationResult.Failure->{val updated=projects.map{proj->if(proj.id!=p.id)proj else proj.copy(scenes=proj.scenes.map{scene->if(scene.id==s.id)scene.copy(status=SceneStatus.FAILED) else scene})};persist(updated);message="FAILED: ${r.message}"};};busy=null}}){Text(if(busy==s.id)"GENERATING…" else if(s.visualAssetPath!=null)"REGENERATE IMAGE" else "GENERATE IMAGE")};Spacer(Modifier.height(8.dp))}}}}}}
}

@Composable fun Settings(secure:SecureTokenStore){var token by remember{mutableStateOf("")};var saved by remember{mutableStateOf(secure.hasToken())};Column{Header("SETTINGS","Generation credentials");Card{Column(Modifier.padding(16.dp)){Text("IMAGE PROVIDER",color=Gold);Text("Replicate • FLUX Schnell");Spacer(Modifier.height(8.dp));OutlinedTextField(token,{token=it},Modifier.fillMaxWidth(),label={Text(if(saved)"Replace API token" else "API token")},singleLine=true);Row{Button(enabled=token.isNotBlank(),onClick={secure.save(token.trim());token="";saved=true}){Text("SAVE SECURELY")};Spacer(Modifier.width(8.dp));OutlinedButton(enabled=saved,onClick={secure.clear();saved=false;token=""}){Text("CLEAR")}};Text(if(saved)"Token stored with Android Keystore encryption" else "No token stored",color=if(saved)Gold else Color.Gray)}};Spacer(Modifier.height(12.dp));Text("CreatorForge never stores generated placeholders as successful media. A scene becomes READY only after a real image is downloaded and its file signature is verified.",color=Color.LightGray)}}
