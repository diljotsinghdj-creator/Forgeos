THE HIDDEN ECONOMICS - 31 SCRIPTS READY FOR CREATORFORGE (24 Shorts + 7 long form)

Every file in shorts/ and long_form/ is copy-paste ready. Open one, copy ALL of it, and paste it into
CreatorForge -> Generate -> Script. CreatorForge reads it like this:
  Line 1 ............ the video name
  On-screen hook: ... big text over the first 3 seconds
  Title / Tags / Source ... go into the post description (Sources are listed one per line)
  Each spoken line .. is narrated exactly as written (headers and directions are never read aloud)
  Visual: ........... the picture for THAT line; it appears exactly when the line starts
  Text: ............. exact words/numbers shown on screen while that line is spoken
  Stock: ............ asks Pixabay/NASA/Wikimedia/Internet Archive/Unsplash for real footage for that line
  Clip: ............. one of YOUR clips plays on that line: upload it first (Library -> ASSET LIBRARY ->
                      + VIDEO), then write its name, e.g. "Clip: delhi march". Add a start time to skip
                      ahead: "Clip: delhi march @ 0:12". Its own sound is removed; only the part that fits
                      the line plays. A name not in your library is reported and the line keeps its picture.
  Draw: ............. a red pen mark that draws itself on over the line's last picture: circle, box, underline
                      (under the Text: callout), arrow, cross or tick - e.g. "Draw: circle" or "Draw: circle, arrow"
  Bubble: / Thought:  a speech bubble / thought cloud that pops in and types its words (keep under ~45 characters)
  Map: .............. an animated map instead of the picture: "Map: France", "Map: Hong Kong | title",
                      "Map: London → Paris" (pins + a route drawing itself)
  Place: ............ a location stamp, e.g. "Place: PARIS · 1925" (pin drops, label types out)
  Cite: ............. the small on-screen source credit, e.g. "Cite: FTC, 2025" -> SOURCE: FTC, 2025
  Chapter: .......... long form: a chapter title card, e.g. "Chapter: Part 1 | The trap"
  Quote: ............ a document card, words typed and highlighted, e.g. "Quote: words | who, year"
  Steps: ............ a flow diagram, boxes drawn one by one with arrows, e.g.
                        "Steps: Free trial → Card saved → Auto-renew | How the trap works"
  Globe: ............ a 3D globe spins and dives onto a country or major city (route arc for two places), e.g.
                        "Globe: France | where it began"   or   "Globe: London → New York"
  Timeline: ......... dates drop onto a line one by one, the last highlighted, e.g.
                        "Timeline: 1890 Born → 1925 Sells the tower → 1947 Dies | His life"
  Icons: ............ a grid of icons pops in and the counted ones fill in, e.g.
                        "Icons: 3 of 4 | sites | used a possible dark pattern"   (people, sites, homes, coins,
                        cards, phones, letters, locks)
  Screen: ........... a recreated (fictional, labelled) app or web page; the camera pushes in on the * row and a
                        red pen circles it, e.g. "Screen: Your plan | Keep my plan · Get 50% off · *small:Cancel"
                        ("small:" = tiny grey text)
  Document: ......... the camera pushes into a document and a highlighter sweeps the quoted line, e.g.
                        "Document: Move your money to a safe account | Example scam script"
  Statement: ........ one big line on a dark screen, word by word, the music drops away, e.g.
                        "Statement: He never *owned* it."   (*word* = highlighted, max 8 words)
  Split: ............ the line's two Visual: pictures side by side with labels, e.g.
                        "Split: What you see | What you pay"   (the line needs 2 Visual: lines)
  Archive: .......... a history line: its pictures look like old photographs with an old-film look, e.g.
                        "Archive: 1920s"
  Object: ........... a simple 3D object, e.g. "Object: coin | £1 | one pound coin" (spins, lands face-on),
                        "Object: card | Subscription card" (flips), "Object: bars | 12, 45, 80 | 2019, 2021, 2023 | Title"
                        (3D bars rise), "Object: stack | 12 | twelve months of £10" (coins pile up)
  Article: .......... the source on screen: a plain page with the publisher's name and the REAL headline, the camera
                        pushes in and it gets highlighted, e.g. "Article: <exact headline> | FTC, July 2024"
  Big: .............. one or two words slam in huge over the picture, e.g. "Big: FREE"
  Transition: ....... the cut into this line: tear (paper rips away), match (zoom-through), whip, iris, flash, dip,
                        slide or wipe. Chapter cards tear and statements dip to dark automatically.
  Chat: ............. a recreated (fictional, labelled) text conversation, bubbles pop in with typing dots, e.g.
                        "Chat: Unknown number | them: Hi, is this Sam? · me: Wrong number · them: Oh sorry!"
  Search: ........... a question types itself into a plain search bar, results appear, e.g.
                        "Search: how to cancel a subscription | Why can't I cancel? · Cancel in 10 steps"
  Pie: .............. a donut fills to the share, e.g. "Pie: 61% | of losses refunded"
  Squares: .......... areas drawn to scale side by side, e.g. "Squares: £4.2m vs £85,000 | fines, one claim"
  Shade: ............ a map with countries shaded by their number, e.g. "Shade: United Kingdom 40%, France 25% | title"
  Timer: ............ a countdown that runs out, e.g. "Timer: 09:59 → 00:00 | Offer ends"
  Receipt: .......... a printed receipt rolls out, the * line circled, the last line the total, e.g.
                        "Receipt: Basket £24.00 · *Service fee £2.50 · Total £26.50"
  Treat: ............ a print look for the line's pictures: duotone or halftone (not full-frame)
  One full-frame graphic per spoken line: Chart, Map, Globe, Steps, Timeline, Icons, Chapter, Quote, Screen,
  Document, Statement, Object, Article, Chat, Search, Pie, Squares, Shade, Timer or Receipt.
  (Split, Archive, Big, Transition and Treat can go anywhere.)
  Also automatic: graphics play at 12 frames a second (the hand-made look), the first photo of each scene slides in
  with motion blur and a projector click, and long widescreen videos end on a 12 s YouTube end screen.
  Automatic: Archive lines use real public-domain archive photos (Wikimedia Commons) when one matches; pen marks
  and bubbles move with the picture they sit on; long videos change music track at each chapter; the channel's
  name signs off the video and sits small on chapter cards and statements (set the name in the Brand kit).
  Sound design is automatic: risers build into chapter cards and statements, hits and pops land on graphics,
  whooshes carry the globe and screen push-ins, and the music dips under chapters and statements.
  Every photo cut-out also moves with 2.5D depth automatically (no key needed).
  Chart: ............ an animated number graphic for that line, e.g.
                        Chart: £12 → £720 | a year of forgotten subscriptions   (counter rolls up)
                        Chart: 48% vs 22% | heavy users, everyone else          (bars grow)
                        Chart: 76% | of 642 sites                               (percentage bar fills)
                        Chart: £1bn → £3bn → £8bn | losses | 2015, 2020, 2025  (line graph draws itself)
                      In Editorial collage / Investigative desk, Text: lines with →, = or "vs" become charts
                      automatically (e.g. "£50 × 12 = £600" counts up to £600).

CHANNEL LOOK (video-essay / Vox style - pick ONE in Visual style; "Mixed-media collage" = Editorial collage)
  Editorial collage ..... each picture's subject is cut out like a sticker (white edge, soft shadow) on cream
                          paper, or shown as a tilted print with a yellow block; black-on-yellow highlighter
                          titles, cream caption strips with key words highlighted, yellow/black charts
  Investigative desk .... the same on a dark wooden desk: prints taped down, red-pen callouts, graph-paper charts
  Both: one clear subject per picture (faces hidden), real footage from Stock: lines plays as a framed clip,
  sliding cuts, a warm paper grade. Add a Pixabay key in Settings.
  For the cleanest look leave "AI video" OFF: cut-out stills with slow camera moves read most like an explainer
  (AI video animates the whole picture, which is then shown as a framed clip instead of a cut-out).
  Pronunciations: Settings -> Pronunciations, e.g. "Ofcom = Off-com" (captions keep your spelling).
  After rendering, the video screen shows a PRE-POST CHECK: loudness (-14 LUFS), clipping, dead air, first
  frame, and whether the narration matched the script. Fix anything marked ⚠ before posting.

SETTINGS
  Shorts (24):     9:16 Shorts, Visual style Editorial collage or Investigative desk, template Cinematic Short, Faceless, Fast cuts, voice pace 1.1x
  Long form (7):   16:9 YouTube, Visual style Investigative desk (07 especially) or Editorial collage, template YouTube Documentary, Faceless, Fast cuts, voice pace 1.0x
  Add a calm/tense instrumental track to the Asset Library first (videos have no music otherwise).
  Restart the pod first (it loads the latest worker) - the cut-out layouts, Vox type and charts are worker features.

EVERY SCRIPT HAS
  - A first line that poses a concrete contradiction, number or personal stake (no intro), over a striking first
    image, and lands within the first 3 seconds (7-8 words; narration starts at 0:00).
  - Shorts run 30-35 seconds (78-90 words); long form runs 6-8 minutes; titles and on-screen hooks lead with the contradiction.
  - A curiosity beat (number, contrast, twist, stakes, tease or question) in every 5 seconds, a bigger
    re-hook at least every 15 seconds in Shorts and every 30 seconds in long
    form - measured on every script - always paid off.
  - Shorts end by looping back to the hook; long form ends by opening the next episode.
  - A new picture about every 2 seconds: lines carry 2-3 Visual: lines, shown in turn while the line is spoken
    (15-18 pictures per Short, ~200 per long form). Every Visual: is one concrete, photographable subject.
  - Numbers spoken in words, exact figures on screen via Text:, key numbers as animated Chart: graphics
    (1-2 per Short, 6-8 per long form), and real footage (Stock:) at the 'this really happened' moments.
  - Invented examples labelled ILLUSTRATION / FICTIONAL on screen; no real company accused.

BEFORE PUBLISHING (YouTube monetisation)
  - Open each Source: link once. Research was checked through search results; some primary pages
    could not be opened from the build machine.
  - Turn on YouTube's "altered or synthetic content" label when a video has realistic AI scenes.
  - Hand-check list (everything else was verified through several search results):
    Short 01   £1.6bn unwanted subscriptions - from news reports; confirm on gov.uk
    Short 03   "nearly 67% used more than one" wording on the FTC/ICPEN page
    Short 04   Ponzi: 45 days (most sources) vs 90 days (Smithsonian); $15m total varies by source
    Short 06   wheel experiment 25% vs 45% (Tversky & Kahneman 1974)
    Short 10   Milgram wall-pounding detail and DOI
    Short 14   7,300 tonnes (commonly cited weight of the tower's iron)
    Short 16   Freedman & Fraser 1966 DOI
    Short 17   FBI IC3 2025 investment-fraud figure ($8.6bn) - open the IC3 report PDF
    Short 20   McAfee "85% match from 3 seconds of audio" page
    Short 21   153 pedestrians (Bickman 1974) and HMRC 170,000 referrals - drop either chart if unsure
    Short 22   Lloyds £3,200 → £3,516 average impersonation loss (Aug 2026 release)
    Short 23   US$25m vs US$25.6m vs £20m (Arup named only as the victim)
    Long 01    "about £14 a month" per unwanted subscription (≈ £1.6bn / 10m / 12)
    Long 02    keyboard bids ($56 vs $16) and estate-agent valuations - from summaries of the papers
    Long 04    TikTok EU findings were PRELIMINARY (Feb 2026) - update if a final decision came out
    Long 05    hook says "valued"; the study measured willingness to pay
    Long 06    Madoff "nearly $65bn on paper" (press figure)
    Long 07    wife's suspicion, the Texas sheriff, the second sale attempt come from popular retellings
               (flagged in the narration); the "Ten Commandments" are shown as ATTRIBUTED

INDEX (title - on-screen hook)
  SHORTS
    01  The Subscription Trap - STOPPED. STILL PAYING?
    02  The Free Trial That Is Not Really Free - FREE → £10?
    03  Where Did the Cancel Button Go - 1 TAP IN, 5 OUT?
    04  The Man Who Invented the Ponzi Scheme - 50% IN 45 DAYS?
    05  The Fake Countdown Question - 00:00. STILL ON SALE?
    06  Why 50 Percent Off Feels Irresistible - SAVED £50? LOST £50?
    07  The Price You Never Notice - £30 → £41?
    08  The Free Gift That Costs You - FREE DRINK. PAID DOUBLE.
    09  The Status Trap - £800 FOR NOBODY?
    10  Why Ordinary People Obey - 2 IN 3 KEPT GOING
    11  The 24 Hour Buying Rule - 11PM. WANT IT TOMORROW?
    12  The Monthly Payment Illusion - £50 = £600?
    13  Why You Cannot Stop Scrolling - CAME FOR THE WEATHER
    14  The Man Who Sold the Eiffel Tower - EIFFEL TOWER, SOLD
    15  Why Notifications Work - 1 BUZZ, 20 MINUTES?
    16  The Small Yes That Leads to a Big Yes - TINY FAVOUR. 17% → 76%
    17  The Stranger Who Texted the Wrong Number - WRONG NUMBER. SAVINGS GONE.
    18  Why Bad News Grabs Attention - 100 CALM DAYS VS 1?
    19  The Cost of Panic Buying - 4 MINUTES. 0 PAGES READ.
    20  The Call That Sounded Like Your Child - HER VOICE. NOT HER.
    21  The Authority Trap - SAME MAN. NEW CLOTHES.
    22  How Scammers Create Urgency - 10 MINUTES OR LOSE IT?
    23  The Video Call Where Everyone Was Fake - FAKE FACES. REAL $25M.
    24  The Question That Breaks the Trap - 1 QUESTION. 3 TRAPS.
  LONG FORM
    01  Why Companies Make Cancelling So Difficult - 10 MILLION UNWANTED
    02  The Discount That Changes Your Brain Before You Buy - THE PRICE YOU NEVER PAY
    03  Why We Buy Things We Cannot Comfortably Afford - THEIR WIN, YOUR DEBT?
    04  How Free Apps Turn Your Attention Into a Business - FREE APP. $160 BILLION.
    05  The Business of Selling You Fear - LESS COVER, HIGHER PRICE?
    06  Why Smart People Fall for Scams - CLEVER ISN'T SAFE
    07  The Man Who Sold the Eiffel Tower - HE SOLD THE EIFFEL TOWER

30-DAY PLAN (one Short a day, one long form a week; each long form is followed by Shorts on the same theme)
  Week 1  money traps        Shorts 01, 02, 03, 07, 12, 06, 05      Long 01 (day 6)
  Week 2  persuasion         Shorts 08, 16, 09, 11, 21, 10, 24      Long 02 (day 13)
  Week 3  attention & fear   Shorts 13, 15, 18, 19, 22, 20, 17      Long 04 (day 20)
  Week 4  scams & cons       Shorts 04, 14, 23  + re-cut best 4     Long 06 (day 25), Long 07 (day 27)
  Days 29-30                 Long 03 and Long 05; then repeat the formats that won (Analytics tab)
  Pin the best Short of each week under the matching long form.

AUTOMATIC PICTURES THAT FOLLOW THE WORDS (new)
  Named subjects: when a line names a person, party, institution, company or landmark ("Modi", "the BJP",
    "Congress", "Rahul Gandhi", "Parliament", "the SEC", "Enron"), CreatorForge shows a real picture of it, found
    by name on Wikipedia/Wikimedia Commons: a party's symbol, a politician's photo, a company logo, a building.
    Shown on the first mention and again at most every few lines, with a different photo where one exists.
    Names the script marks as made up ("Text: LEAH · FICTIONAL", "Sam is fictional") are never looked up.
  Everyday things: when the words mention something concrete ("discount", "vote", "ballot", "subscription",
    "credit card", "police", "protest", "newspaper") and the line's Visual shows something else, the picture is
    swapped for one of exactly that thing.
  Left alone: lines with a full-frame graphic (Chart, Map, Statement...), Split screens, Archive lines and any line
    with your own Stock: search. To keep your own picture on a line, give it a Stock: line.
  Check these real pictures in the storyboard review before rendering.
